//
//  MobiusApp.swift
//  Mobius
//
//  Created by Luciano Di Croce on 9/8/25.
//

import SwiftUI

@main
struct MobiusApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
           //  SixtyMinuteGauge()
        }
    }
}
